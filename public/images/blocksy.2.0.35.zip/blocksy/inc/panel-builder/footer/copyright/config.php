<?php
$config = [
	'name' => __('Copyright', 'blocksy'),
	// 'clone' => true,
	'typography_keys' => ['copyrightFont'],
	'translation_keys' => [
		['key' => 'copyright_text']
	]
];
