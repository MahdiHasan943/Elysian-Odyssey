<?php

$config = [
	'name' => __('Widget Area 1', 'blocksy')
];


